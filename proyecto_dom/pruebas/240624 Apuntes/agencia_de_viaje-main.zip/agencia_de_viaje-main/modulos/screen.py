import os

def clear_screen():
    os.system('cls')

def pause_screen():
    print('Pulse enter para continuar\n')
    input()