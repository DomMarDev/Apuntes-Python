from modulos.mostrar_destino import mostrar_destinos as md

def anadir_destino(destinos):
    ''' 
        Función que permite añadir un destino a la lista "destinos".

        Entradas:
            - Código del destino
            - Nombre del destino
            - Precio del destino
        Operaciones:
            -Añadir a la lista de destinos los destinos que quiera el usuario (se le solicita si quiere continuar o no con *)

        Salidas:
            - Lista de destinos actualizada
    '''
    while True:
        if destinos:
            print(f'Tenemos destinos en nuestra base de datos.\n')
            md(destinos)
        else:
            print('No hay destinos en nuestra base de datos')

        print(f'A continuación vas a introducir un nuevo destino a nuestra base de datos.\n Necesitarás:\n \t-Código de destino\n \t-Nombre del destino\n \t-Precio del destino (€)')
        
        while True:
            codigo = input('Introduce el código asociado al destino').lower()

            if not codigo:
                print(f'\nNo has introducido un código de destino')
            else:
                break
                
        while True:
            destino = input('Introduce el destino').lower()
            
            if not destino:
                print(f'\nNo has introducido un destino.')
            else:
                break

        while True:
            try:
                precio= float(input(f'Introduce (en €) el precio de ir al destino {destino.title()}: '))
                break
            
            except ValueError:
                print('Has de introducir el precio (en €) como un número.')
        
        destinos.append({'codigo destino': codigo, 'nombre destino': destino, 'precio destino': precio})
        
        print(f'El nuevo destino {destino.title()} con código {codigo} se ha añadido con éxito y su precio será {precio} €.')
        
        epilogue = input('Para seguir añadiendo destinos presiona enter. Si no, puedes presionar * para volverte al menu principal. \n')
        if epilogue == '*':
            break
        else:
            continue



    return destinos