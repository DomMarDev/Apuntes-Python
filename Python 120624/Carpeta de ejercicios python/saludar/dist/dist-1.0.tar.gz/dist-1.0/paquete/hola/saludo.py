def saludar():
    print('Hola, estoy saludando desde la función saludar() de módulo saludo')