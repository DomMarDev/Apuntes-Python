def despedir():
    print('Adios, estoy despidiendome desde la función despedir() de módulo despedida')