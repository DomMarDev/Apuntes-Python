from setuptools import setup
setup(
    name = 'dist',
    version = '1.0',
    description = 'Esto es un paquede de ejemplo',
    autor = 'Domingo Marchan',
    mail = 'Domingo-marchan@hotmail.com',
    url = 'www.urldedomingo.com',
    packages = ['paquete', 'paquete.hola', 'paquete.adios'],
    scripts = []
)